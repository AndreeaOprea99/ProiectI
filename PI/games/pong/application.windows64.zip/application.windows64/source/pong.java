import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class pong extends PApplet {

float player_x;
float player_y;
float ball_x;
float ball_y;
float ball_speed_x;
float ball_speed_y;

int runde;

public void setup(){
  player_x = 20;
  player_y = 60;
  ball_x = 400;
  ball_y = 300;
 ball_speed_x = -4;
 ball_speed_y =  0; 
 runde = 0;
  
  rectMode(CENTER);
}

public void draw(){
  background(0);
  rect(ball_x,ball_y,10,10);
  rect(player_x, player_y, 20, 100);
  if(keyPressed){
    if(keyCode == DOWN){
       if(player_y < 550){
      player_y = player_y + 5; 
  }
  }
  }
if(keyCode == UP){
  if(player_y > 50){
  player_y = player_y - 5;
}     
}
ball_x = ball_x + ball_speed_x;
ball_y = ball_y + ball_speed_y;
if (ball_x < 30){
   if(ball_y < (player_y + 55) && ball_y > (player_y - 55)){
   ball_speed_x = (-ball_speed_x) + 1;
   ball_speed_y = ball_speed_y  - (player_y - ball_y) * 0.1f;
   runde = runde + 1;
 }else{
   ball_x = 400;
   ball_y = 300;
   ball_speed_x = -4;
   ball_speed_y = 0;
   runde = 0;
   }
}
 if(ball_y > 595 || ball_y < 5){
  ball_speed_y = -ball_speed_y; 
 }
if(ball_x > 795){
   ball_speed_x = -ball_speed_x;
}
 text("Runde: " + runde, 700, 20);
 
}
  public void settings() {  size(800, 600); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "pong" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
